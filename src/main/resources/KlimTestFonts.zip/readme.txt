Klim Type Foundry test fonts

Use these test fonts to mock up your print, web or app designs for approval before licensing the full versions.

This download includes:
- All of our retail fonts
- OpenType Format (.otf) files
- Web Open Font Format 2.0 (.woff2) files

Our test font family names are prefixed with “Test”.

Test fonts have no OpenType features and a limited character set:

ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
0123456789 .,-

By using these fonts you agree to our Test Font Licence Agreement.
